<?php
include "config.php";

if(isset($_GET['tracking_number'])){
    $tracking_number = $_GET['tracking_number'];
    $sql = "SELECT * FROM packages WHERE tracking_number='$tracking_number'";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
    } else {
        die("<div class='container mt-5'><div class='alert alert-danger'>Tracking number not found.</div></div>");
    }
} else {
    die("Invalid Request.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tracking Result</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="card shadow p-4">
    <h3 class="text-center">Tracking Number: <?= $row['tracking_number']; ?></h3>
    <hr>
    <p><strong>Status:</strong> <?= $row['status']; ?></p>
    <p><strong>Last Updated:</strong> <?= $row['last_update']; ?></p>
    <h4>Sender Information</h4>
    <p><?= $row['sender_name']; ?> <br><?= $row['sender_address']; ?> <br><?= $row['sender_phone']; ?></p>
    <h4>Receiver Information</h4>
    <p><?= $row['receiver_name']; ?> <br><?= $row['receiver_address']; ?> <br><?= $row['receiver_phone']; ?> <br><?= $row['receiver_email']; ?></p>
    <h4>Shipment Details</h4>
    <p><strong>Weight:</strong> <?= $row['weight']; ?> <br><strong>Type:</strong> <?= $row['type']; ?> <br><strong>Shipped:</strong> <?= $row['ship_date']; ?></p>
    <?php if(!empty($row['image'])): ?>
      <img src="assets/uploads/<?= $row['image']; ?>" width="200" class="img-thumbnail mt-2">
    <?php endif; ?>
  </div>
</div>
</body>
</html>